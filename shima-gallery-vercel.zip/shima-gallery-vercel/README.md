# Shima Gallery - Setup Instructions

## 1. Resend Account erstellen
- Gehe zu https://resend.com
- Erstelle kostenlosen Account
- API Key generieren
- Domain verifizieren

## 2. Vercel Deployment
- Lade alle Dateien auf Vercel hoch
- Setze Environment Variables:
  - RESEND_API_KEY=dein_resend_api_key
  - TO_EMAIL=deine@email.com

## 3. Projekt starten
- Das Projekt wird automatisch auf Vercel deployed
- Formular sendet Emails über Resend

## Projektstruktur
